package com.iamsalih.openweatherapplication

/**
 * Created by muhammedsalihguler on 30.07.17.
 */
enum class ErrorTypes {
    MISSING_API_KEY, NO_RESULT_FOUND, CALL_ERROR
}