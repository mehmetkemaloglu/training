# Open Weather Application with Kotlin

This a sample application for Kotlin in android with Open Weather API.
